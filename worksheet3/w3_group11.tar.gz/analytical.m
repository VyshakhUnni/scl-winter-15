function result = analytical(x, y)
result = sin(pi * x) .* sin(pi * y);
end