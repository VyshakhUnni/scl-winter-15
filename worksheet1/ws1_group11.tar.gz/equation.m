function p = equation(y)
p = (1 - (y ./ 10)) .* y;
end
