function p = Analytical(t)
p = 10 ./ (1 + 9 * exp(-t)); % element-wise division operator
end
