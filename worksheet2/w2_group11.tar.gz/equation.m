function result = equation (y)
result = 7 * (1 - y / 10) * y;
end