function df = derivative (t)
df = 7 * (1 - t / 5);
end