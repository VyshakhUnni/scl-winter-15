function result = equation(x, y)
result = -2 * pi^2 * sin(pi * x) .* sin(pi * y);
end