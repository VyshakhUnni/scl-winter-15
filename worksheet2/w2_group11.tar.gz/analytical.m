function result = analytical(t)
result = 200 ./ (20 - 10 * exp(-7 * t));
end